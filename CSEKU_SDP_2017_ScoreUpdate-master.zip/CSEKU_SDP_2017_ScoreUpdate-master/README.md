# CSEKU_SDP_2017_ScoreUpdate

This is a Software Devolopement Project of 2-2 term of Khulna University.



Project Title: Score Update



Project Description:

        Programming Language: HTML, CSS, PHP & JAVAScript

        Database: MySql

        Project Location: Khulna University, Khulna, Bangladesh



Project Manager:

	Dr.Kazi Masudul Alam

	Associate Professor

	Computer Science & Engineering Discipline

	Khulna University,Khulna,Bangladesh

	&

	Dr. Manishankar Mondal

	Assistant Professor

	Computer Science & Engineering Discipline

	Khulna University,Khulna,Bangladesh

Developed By:
	
	MD. Siamul Haque
	St. ID: 150226
	MD. Moniruzzaman
	St. ID: 150227
	Tanvir Hasan
	St. ID: 150234
	
Project Description:

	This is the project of Live Cricket Score Board with Auto Update.
	In this project super admin can create multiple Cricket matches and assign
	a admin to control the game.
	General users can see those games status with auto update.
